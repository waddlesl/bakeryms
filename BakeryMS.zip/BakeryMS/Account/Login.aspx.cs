﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BakeryMS.DAL;

namespace BakeryMS.Account
{
    public partial class Login : System.Web.UI.Page
    {
        AccManagementDAL accManager = new AccManagementDAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false; // Hide message on page load
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            string role = accManager.ValidateUser(email, password);

            if (role == null)
            {
                lblMessage.Visible = true;
                lblMessage.CssClass = "text-danger";
                lblMessage.Text = "Invalid email or password. Try again.";
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.CssClass = "text-success"; 
                lblMessage.Text = "Login successful! Redirecting...";

                // store user details in session
                Session["UserEmail"] = email;
                Session["UserRole"] = role;

                // redirect based on role
                if (role == "Admin")
                {
                    Response.Redirect("~/Admin/AdminAccManagement.aspx");
                }
                else if (role == "Customer")
                {
                    Response.Redirect("~/Customer/Home.aspx");
                }
            }
        }
    }
}
