﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BakeryMS.Account
{
    public partial class UserAccSettings : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Make sure session variables are available
            if (Session["UserFirstName"] != null)
            {
                lblEmail.Text = "Email: " + Session["UserEmail"].ToString();
                lblRole.Text = "Role: " + Session["UserRole"].ToString();
            }

        }
    }
}